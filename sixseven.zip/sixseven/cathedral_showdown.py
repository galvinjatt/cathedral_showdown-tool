"""
CATHEDRAL SHOWDOWN - 3D Bootleg Ultrakill
A Python 3D FPS using Pygame + PyOpenGL
Requires: pip install pygame PyOpenGL PyOpenGL_accelerate numpy
"""

import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import math
import random
import sys

# ============ CONFIG ============
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
BASE_FOV = 75
SPRINT_FOV = 88
NEAR_PLANE = 0.1
FAR_PLANE = 200

# Game constants
PLAYER_SPEED = 0.11
PLAYER_SPRINT = 0.20
PLAYER_ACCEL = 0.025
PLAYER_FRICTION = 0.82
MOUSE_SENSITIVITY = 0.14
MOUSE_SMOOTH = 0.35
INVERT_Y = True            # <-- flipped for you
BULLET_SPEED = 1.2
BULLET_LIFETIME = 120
ENEMY_SPEED = 0.035
ENEMY_SPAWN_INTERVAL = 120
MAX_AMMO = 12
RELOAD_TIME = 40
MAX_HEALTH = 100
ARENA_SIZE = 40

# ============ INIT ============
pygame.init()
pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), DOUBLEBUF | OPENGL)
pygame.display.set_caption("CATHEDRAL SHOWDOWN")
pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

glEnable(GL_DEPTH_TEST)
glEnable(GL_LIGHTING)
glEnable(GL_LIGHT0)
glEnable(GL_COLOR_MATERIAL)
glEnable(GL_NORMALIZE)
glEnable(GL_BLEND)
glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
glClearColor(0.02, 0.01, 0.01, 1.0)
glShadeModel(GL_SMOOTH)

glEnable(GL_FOG)
glFogfv(GL_FOG_COLOR, [0.05, 0.02, 0.02, 1.0])
glFogi(GL_FOG_MODE, GL_EXP2)
glFogf(GL_FOG_DENSITY, 0.04)

glLightfv(GL_LIGHT0, GL_POSITION, [10.0, 20.0, 10.0, 1.0])
glLightfv(GL_LIGHT0, GL_AMBIENT, [0.15, 0.1, 0.1, 1.0])
glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.8, 0.6, 0.5, 1.0])
glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 0.8, 0.6, 1.0])

pygame.font.init()
font_big = pygame.font.SysFont("Courier New", 36, bold=True)
font_med = pygame.font.SysFont("Courier New", 24, bold=True)
font_small = pygame.font.SysFont("Courier New", 18, bold=True)
font_giant = pygame.font.SysFont("Courier New", 72, bold=True)

# ============ GAME STATE ============


class GameState:
    def __init__(self):
        self.reset()

    def reset(self):
        self.player_pos = [0.0, 1.7, 0.0]
        self.velocity = [0.0, 0.0]
        self.player_yaw = 0.0
        self.player_pitch = 0.0
        self.target_yaw = 0.0
        self.target_pitch = 0.0
        self.mouse_vel_x = 0.0
        self.mouse_vel_y = 0.0

        self.bob_phase = 0.0
        self.bob_amount = 0.0
        self.roll = 0.0
        self.target_roll = 0.0

        self.land_dip = 0.0
        self.fov_current = BASE_FOV

        self.weapon_sway_x = 0.0
        self.weapon_sway_y = 0.0

        self.health = MAX_HEALTH
        self.score = 0
        self.ammo = MAX_AMMO
        self.reloading = False
        self.reload_timer = 0
        self.bullets = []
        self.enemies = []
        self.spawn_timer = 0
        self.game_active = True
        self.shake = 0.0
        self.hit_flash = 0.0
        self.recoil = 0.0
        self.muzzle_flash = 0.0
        self.kill_effects = []


state = GameState()

# ============ CATHEDRAL GEOMETRY ============


def draw_floor():
    tile = 4.0
    size = ARENA_SIZE
    for x in range(-size, size, int(tile)):
        for z in range(-size, size, int(tile)):
            cx = (x // int(tile))
            cz = (z // int(tile))
            if (cx + cz) % 2 == 0:
                glColor3f(0.12, 0.09, 0.08)
            else:
                glColor3f(0.08, 0.06, 0.05)
            glBegin(GL_QUADS)
            glNormal3f(0, 1, 0)
            glVertex3f(x, 0, z)
            glVertex3f(x + tile, 0, z)
            glVertex3f(x + tile, 0, z + tile)
            glVertex3f(x, 0, z + tile)
            glEnd()


def draw_ceiling():
    glColor3f(0.05, 0.03, 0.03)
    glBegin(GL_QUADS)
    glNormal3f(0, -1, 0)
    glVertex3f(-ARENA_SIZE, 12, -ARENA_SIZE)
    glVertex3f(-ARENA_SIZE, 12, ARENA_SIZE)
    glVertex3f(ARENA_SIZE, 12, ARENA_SIZE)
    glVertex3f(ARENA_SIZE, 12, -ARENA_SIZE)
    glEnd()


def draw_wall(x, z, rot_y):
    glPushMatrix()
    glTranslatef(x, 0, z)
    glRotatef(rot_y, 0, 1, 0)

    wall_len = ARENA_SIZE * 2
    wall_height = 12

    glColor3f(0.10, 0.07, 0.06)
    glBegin(GL_QUADS)
    glNormal3f(0, 0, 1)
    glVertex3f(-wall_len, 0, 0)
    glVertex3f(wall_len, 0, 0)
    glVertex3f(wall_len, wall_height, 0)
    glVertex3f(-wall_len, wall_height, 0)
    glEnd()

    glColor3f(0.07, 0.05, 0.04)
    glLineWidth(1.5)
    for y in range(1, wall_height, 1):
        glBegin(GL_LINES)
        glVertex3f(-wall_len, y, 0.01)
        glVertex3f(wall_len, y, 0.01)
        glEnd()
    for i in range(-int(wall_len), int(wall_len), 2):
        offset = 1 if (i // 2) % 2 == 0 else 0
        glBegin(GL_LINES)
        glVertex3f(i, offset, 0.01)
        glVertex3f(i, wall_height, 0.01)
        glEnd()

    glDisable(GL_LIGHTING)
    for wx in range(-int(wall_len) + 4, int(wall_len) - 2, 10):
        glColor3f(0.3, 0.05, 0.05)
        glBegin(GL_QUADS)
        glVertex3f(wx - 2, 4, 0.02)
        glVertex3f(wx + 2, 4, 0.02)
        glVertex3f(wx + 2, 10, 0.02)
        glVertex3f(wx - 2, 10, 0.02)
        glEnd()
        glColor4f(1.0, 0.3, 0.1, 0.6)
        glBegin(GL_QUADS)
        glVertex3f(wx - 1.5, 4.5, 0.03)
        glVertex3f(wx + 1.5, 4.5, 0.03)
        glVertex3f(wx + 1.5, 9.5, 0.03)
        glVertex3f(wx - 1.5, 9.5, 0.03)
        glEnd()
        glBegin(GL_TRIANGLES)
        glVertex3f(wx - 1.5, 9.5, 0.03)
        glVertex3f(wx + 1.5, 9.5, 0.03)
        glVertex3f(wx, 11, 0.03)
        glEnd()
    glEnable(GL_LIGHTING)

    glPopMatrix()


def draw_pillar(x, z):
    glPushMatrix()
    glTranslatef(x, 0, z)

    glColor3f(0.08, 0.06, 0.05)
    glBegin(GL_QUADS)
    for i in range(4):
        a = i * math.pi / 2
        b = (i + 1) * math.pi / 2
        glNormal3f(math.cos(a), 0, math.sin(a))
        glVertex3f(math.cos(a) * 1.2, 0, math.sin(a) * 1.2)
        glVertex3f(math.cos(b) * 1.2, 0, math.sin(b) * 1.2)
        glVertex3f(math.cos(b) * 1.2, 0.5, math.sin(b) * 1.2)
        glVertex3f(math.cos(a) * 1.2, 0.5, math.sin(a) * 1.2)
    glEnd()

    glColor3f(0.13, 0.10, 0.08)
    segments = 12
    for y in range(0, 11):
        glBegin(GL_QUAD_STRIP)
        for i in range(segments + 1):
            a = (i / segments) * math.pi * 2
            r = 0.8 + math.sin(a * 4) * 0.05
            nx = math.cos(a)
            nz = math.sin(a)
            glNormal3f(nx, 0, nz)
            glVertex3f(nx * r, y, nz * r)
            glVertex3f(nx * r, y + 1, nz * r)
        glEnd()

    glColor3f(0.08, 0.06, 0.05)
    glBegin(GL_QUADS)
    for i in range(4):
        a = i * math.pi / 2
        b = (i + 1) * math.pi / 2
        glNormal3f(math.cos(a), 0, math.sin(a))
        glVertex3f(math.cos(a) * 1.2, 11, math.sin(a) * 1.2)
        glVertex3f(math.cos(b) * 1.2, 11, math.sin(b) * 1.2)
        glVertex3f(math.cos(b) * 1.2, 12, math.sin(b) * 1.2)
        glVertex3f(math.cos(a) * 1.2, 12, math.sin(a) * 1.2)
    glEnd()

    glPopMatrix()


def draw_altar():
    glPushMatrix()
    glTranslatef(0, 0, -15)

    glColor3f(0.15, 0.10, 0.08)
    glBegin(GL_QUADS)
    glNormal3f(0, 1, 0)
    glVertex3f(-4, 0.6, -4)
    glVertex3f(4, 0.6, -4)
    glVertex3f(4, 0.6, 4)
    glVertex3f(-4, 0.6, 4)
    glNormal3f(0, 0, 1)
    glVertex3f(-4, 0, 4)
    glVertex3f(4, 0, 4)
    glVertex3f(4, 0.6, 4)
    glVertex3f(-4, 0.6, 4)
    glNormal3f(0, 0, -1)
    glVertex3f(-4, 0, -4)
    glVertex3f(4, 0, -4)
    glVertex3f(4, 0.6, -4)
    glVertex3f(-4, 0.6, -4)
    glNormal3f(1, 0, 0)
    glVertex3f(4, 0, -4)
    glVertex3f(4, 0, 4)
    glVertex3f(4, 0.6, 4)
    glVertex3f(4, 0.6, -4)
    glNormal3f(-1, 0, 0)
    glVertex3f(-4, 0, -4)
    glVertex3f(-4, 0, 4)
    glVertex3f(-4, 0.6, 4)
    glVertex3f(-4, 0.6, -4)
    glEnd()

    glDisable(GL_LIGHTING)
    glColor4f(0.9, 0.1, 0.1, 0.7)
    quad = gluNewQuadric()
    glPushMatrix()
    glTranslatef(0, 1.8, 0)
    gluSphere(quad, 0.6, 16, 16)
    glPopMatrix()
    gluDeleteQuadric(quad)
    glEnable(GL_LIGHTING)

    glPopMatrix()


def draw_cathedral():
    draw_floor()
    draw_ceiling()
    draw_wall(0, -ARENA_SIZE, 0)
    draw_wall(0, ARENA_SIZE, 180)
    draw_wall(-ARENA_SIZE, 0, 90)
    draw_wall(ARENA_SIZE, 0, -90)
    for x in [-12, 12]:
        for z in [-12, -4, 4, 12]:
            draw_pillar(x, z)
    draw_altar()

# ============ ENEMIES ============


def draw_enemy(e):
    glPushMatrix()
    glTranslatef(e['pos'][0], e['pos'][1], e['pos'][2])
    angle = math.degrees(math.atan2(
        state.player_pos[0] - e['pos'][0],
        state.player_pos[2] - e['pos'][2]
    ))
    glRotatef(angle, 0, 1, 0)
    pulse = 0.5 + math.sin(e['phase']) * 0.1

    glColor3f(0.35, 0.05, 0.05)
    quad = gluNewQuadric()
    glPushMatrix()
    gluSphere(quad, 0.7, 12, 12)
    glPopMatrix()

    glDisable(GL_LIGHTING)
    glColor4f(1.0, 0.2, 0.1, 0.6)
    glPushMatrix()
    gluSphere(quad, 0.4 * pulse, 10, 10)
    glPopMatrix()
    glEnable(GL_LIGHTING)

    glColor3f(0.15, 0.05, 0.05)
    glPushMatrix()
    glTranslatef(-0.4, 0.5, 0)
    glRotatef(-30, 0, 0, 1)
    glBegin(GL_TRIANGLES)
    glVertex3f(-0.15, 0, 0)
    glVertex3f(0.15, 0, 0)
    glVertex3f(0, 0.8, 0)
    glEnd()
    glPopMatrix()
    glPushMatrix()
    glTranslatef(0.4, 0.5, 0)
    glRotatef(30, 0, 0, 1)
    glBegin(GL_TRIANGLES)
    glVertex3f(-0.15, 0, 0)
    glVertex3f(0.15, 0, 0)
    glVertex3f(0, 0.8, 0)
    glEnd()
    glPopMatrix()

    glDisable(GL_LIGHTING)
    glColor4f(1.0, 0.9, 0.2, 1.0)
    glPushMatrix()
    glTranslatef(-0.25, 0.2, 0.55)
    gluSphere(quad, 0.1, 8, 8)
    glPopMatrix()
    glPushMatrix()
    glTranslatef(0.25, 0.2, 0.55)
    gluSphere(quad, 0.1, 8, 8)
    glPopMatrix()
    glEnable(GL_LIGHTING)

    gluDeleteQuadric(quad)
    glPopMatrix()

# ============ BULLETS ============


def draw_bullet(b):
    glPushMatrix()
    glTranslatef(b['pos'][0], b['pos'][1], b['pos'][2])
    glDisable(GL_LIGHTING)
    glColor4f(1.0, 0.9, 0.3, 1.0)
    quad = gluNewQuadric()
    gluSphere(quad, 0.08, 8, 8)
    gluDeleteQuadric(quad)
    glColor4f(1.0, 0.5, 0.1, 0.4)
    glPushMatrix()
    glTranslatef(-b['vel'][0] * 3, -b['vel'][1] * 3, -b['vel'][2] * 3)
    quad = gluNewQuadric()
    gluSphere(quad, 0.15, 8, 8)
    gluDeleteQuadric(quad)
    glPopMatrix()
    glEnable(GL_LIGHTING)
    glPopMatrix()

# ============ WEAPON VIEWMODEL ============


def draw_weapon():
    glClear(GL_DEPTH_BUFFER_BIT)
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    glOrtho(-1, 1, -1, 1, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()
    glDisable(GL_LIGHTING)
    glDisable(GL_FOG)

    bob_x = math.sin(state.bob_phase) * 0.015 * state.bob_amount
    bob_y = abs(math.cos(state.bob_phase)) * 0.02 * state.bob_amount
    recoil_y = state.recoil * 0.15
    recoil_rot = state.recoil * 15

    sway_x = state.weapon_sway_x * 0.06
    sway_y = state.weapon_sway_y * 0.06

    glTranslatef(0.35 + bob_x + sway_x,
                 -0.35 + bob_y + recoil_y + sway_y,
                 0)
    glRotatef(-recoil_rot, 1, 0, 0)
    glRotatef(state.weapon_sway_x * 8, 0, 1, 0)
    glRotatef(state.weapon_sway_y * 6, 1, 0, 0)

    glColor3f(0.15, 0.15, 0.18)
    glBegin(GL_QUADS)
    glVertex3f(-0.15, 0.15, 0)
    glVertex3f(0.15, 0.15, 0)
    glVertex3f(0.15, 0.15, -0.5)
    glVertex3f(-0.15, 0.15, -0.5)
    glVertex3f(-0.15, -0.15, 0)
    glVertex3f(0.15, -0.15, 0)
    glVertex3f(0.15, -0.15, -0.5)
    glVertex3f(-0.15, -0.15, -0.5)
    glVertex3f(-0.15, -0.15, -0.5)
    glVertex3f(0.15, -0.15, -0.5)
    glVertex3f(0.15, 0.15, -0.5)
    glVertex3f(-0.15, 0.15, -0.5)
    glVertex3f(-0.15, -0.15, 0)
    glVertex3f(-0.15, -0.15, -0.5)
    glVertex3f(-0.15, 0.15, -0.5)
    glVertex3f(-0.15, 0.15, 0)
    glVertex3f(0.15, -0.15, 0)
    glVertex3f(0.15, -0.15, -0.5)
    glVertex3f(0.15, 0.15, -0.5)
    glVertex3f(0.15, 0.15, 0)
    glEnd()

    glColor3f(0.08, 0.08, 0.10)
    glBegin(GL_QUADS)
    glVertex3f(-0.05, 0.05, -0.5)
    glVertex3f(0.05, 0.05, -0.5)
    glVertex3f(0.05, 0.05, -0.85)
    glVertex3f(-0.05, 0.05, -0.85)
    glVertex3f(-0.05, -0.05, -0.5)
    glVertex3f(0.05, -0.05, -0.5)
    glVertex3f(0.05, -0.05, -0.85)
    glVertex3f(-0.05, -0.05, -0.85)
    glVertex3f(-0.05, -0.05, -0.5)
    glVertex3f(-0.05, 0.05, -0.5)
    glVertex3f(-0.05, 0.05, -0.85)
    glVertex3f(-0.05, -0.05, -0.85)
    glVertex3f(0.05, -0.05, -0.5)
    glVertex3f(0.05, 0.05, -0.5)
    glVertex3f(0.05, 0.05, -0.85)
    glVertex3f(0.05, -0.05, -0.85)
    glVertex3f(-0.05, -0.05, -0.85)
    glVertex3f(0.05, -0.05, -0.85)
    glVertex3f(0.05, 0.05, -0.85)
    glVertex3f(-0.05, 0.05, -0.85)
    glEnd()

    glColor3f(0.8, 0.1, 0.1)
    glBegin(GL_QUADS)
    glVertex3f(-0.16, 0.0, -0.1)
    glVertex3f(-0.16, 0.0, -0.4)
    glVertex3f(-0.16, 0.08, -0.4)
    glVertex3f(-0.16, 0.08, -0.1)
    glEnd()
    glBegin(GL_QUADS)
    glVertex3f(0.16, 0.0, -0.1)
    glVertex3f(0.16, 0.0, -0.4)
    glVertex3f(0.16, 0.08, -0.4)
    glVertex3f(0.16, 0.08, -0.1)
    glEnd()

    if state.muzzle_flash > 0:
        glDisable(GL_DEPTH_TEST)
        glColor4f(1.0, 0.8, 0.2, state.muzzle_flash)
        quad = gluNewQuadric()
        glPushMatrix()
        glTranslatef(0, 0, -0.9)
        gluSphere(quad, 0.15 * state.muzzle_flash, 8, 8)
        glPopMatrix()
        glColor4f(1.0, 0.9, 0.5, state.muzzle_flash * 0.8)
        glBegin(GL_QUADS)
        glVertex3f(-0.3, -0.05, -0.9)
        glVertex3f(0.3, -0.05, -0.9)
        glVertex3f(0.3, 0.05, -0.9)
        glVertex3f(-0.3, 0.05, -0.9)
        glEnd()
        glBegin(GL_QUADS)
        glVertex3f(-0.05, -0.3, -0.9)
        glVertex3f(0.05, -0.3, -0.9)
        glVertex3f(0.05, 0.3, -0.9)
        glVertex3f(-0.05, 0.3, -0.9)
        glEnd()
        gluDeleteQuadric(quad)
        glEnable(GL_DEPTH_TEST)

    glEnable(GL_LIGHTING)
    glEnable(GL_FOG)
    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)

# ============ CROSSHAIR & HUD ============


def draw_crosshair():
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    glOrtho(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()
    glDisable(GL_LIGHTING)
    glDisable(GL_DEPTH_TEST)
    glDisable(GL_FOG)

    cx, cy = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2
    size = 15
    gap = 5

    if state.hit_flash > 0:
        glColor4f(1.0, 0.2, 0.2, state.hit_flash)
        glLineWidth(4)
    else:
        glColor4f(1.0, 1.0, 1.0, 0.9)
        glLineWidth(2)

    glBegin(GL_LINES)
    glVertex2f(cx, cy - gap)
    glVertex2f(cx, cy - gap - size)
    glVertex2f(cx, cy + gap)
    glVertex2f(cx, cy + gap + size)
    glVertex2f(cx - gap, cy)
    glVertex2f(cx - gap - size, cy)
    glVertex2f(cx + gap, cy)
    glVertex2f(cx + gap + size, cy)
    glEnd()

    glPointSize(3)
    glBegin(GL_POINTS)
    glVertex2f(cx, cy)
    glEnd()

    glEnable(GL_FOG)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_LIGHTING)
    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)


def draw_hud():
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    glOrtho(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()
    glDisable(GL_LIGHTING)
    glDisable(GL_DEPTH_TEST)
    glDisable(GL_FOG)

    glColor4f(0.05, 0.02, 0.02, 0.85)
    glBegin(GL_QUADS)
    glVertex2f(30, WINDOW_HEIGHT - 90)
    glVertex2f(330, WINDOW_HEIGHT - 90)
    glVertex2f(330, WINDOW_HEIGHT - 40)
    glVertex2f(30, WINDOW_HEIGHT - 40)
    glEnd()

    health_pct = max(0, state.health) / MAX_HEALTH
    if health_pct > 0.5:
        glColor4f(0.9, 0.15, 0.15, 1.0)
    elif health_pct > 0.25:
        glColor4f(1.0, 0.5, 0.1, 1.0)
    else:
        pulse = 0.6 + math.sin(pygame.time.get_ticks() * 0.01) * 0.4
        glColor4f(1.0, 0.1, 0.1, pulse)

    glBegin(GL_QUADS)
    glVertex2f(35, WINDOW_HEIGHT - 85)
    glVertex2f(35 + 290 * health_pct, WINDOW_HEIGHT - 85)
    glVertex2f(35 + 290 * health_pct, WINDOW_HEIGHT - 45)
    glVertex2f(35, WINDOW_HEIGHT - 45)
    glEnd()

    glColor4f(0.5, 0.1, 0.1, 1.0)
    glLineWidth(2)
    glBegin(GL_LINE_LOOP)
    glVertex2f(30, WINDOW_HEIGHT - 90)
    glVertex2f(330, WINDOW_HEIGHT - 90)
    glVertex2f(330, WINDOW_HEIGHT - 40)
    glVertex2f(30, WINDOW_HEIGHT - 40)
    glEnd()

    glColor4f(0.05, 0.02, 0.02, 0.85)
    glBegin(GL_QUADS)
    glVertex2f(WINDOW_WIDTH - 330, WINDOW_HEIGHT - 90)
    glVertex2f(WINDOW_WIDTH - 30, WINDOW_HEIGHT - 90)
    glVertex2f(WINDOW_WIDTH - 30, WINDOW_HEIGHT - 40)
    glVertex2f(WINDOW_WIDTH - 330, WINDOW_HEIGHT - 40)
    glEnd()

    for i in range(MAX_AMMO):
        px = WINDOW_WIDTH - 320 + i * 24
        py = WINDOW_HEIGHT - 65
        if i < state.ammo:
            glColor4f(1.0, 0.8, 0.2, 1.0)
        else:
            glColor4f(0.2, 0.15, 0.05, 0.6)
        glBegin(GL_QUADS)
        glVertex2f(px, py - 15)
        glVertex2f(px + 16, py - 15)
        glVertex2f(px + 16, py + 15)
        glVertex2f(px, py + 15)
        glEnd()

    if state.reloading:
        pct = 1.0 - (state.reload_timer / RELOAD_TIME)
        glColor4f(1.0, 0.5, 0.1, 0.8)
        glBegin(GL_QUADS)
        glVertex2f(WINDOW_WIDTH - 330, WINDOW_HEIGHT - 35)
        glVertex2f(WINDOW_WIDTH - 330 + 300 * pct, WINDOW_HEIGHT - 35)
        glVertex2f(WINDOW_WIDTH - 330 + 300 * pct, WINDOW_HEIGHT - 30)
        glVertex2f(WINDOW_WIDTH - 330, WINDOW_HEIGHT - 30)
        glEnd()

    glEnable(GL_FOG)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_LIGHTING)
    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)


def draw_hud_text():
    health_text = font_med.render(
        f"HEALTH: {state.health}", True, (255, 220, 220))
    screen.blit(health_text, (45, WINDOW_HEIGHT - 80))

    score_text = font_med.render(
        f"SOULS: {state.score}", True, (255, 220, 100))
    screen.blit(score_text, (WINDOW_WIDTH // 2 - 80, 20))

    ammo_str = "RELOADING..." if state.reloading else f"{state.ammo} / {MAX_AMMO}"
    ammo_text = font_med.render(ammo_str, True, (255, 220, 100))
    screen.blit(ammo_text, (WINDOW_WIDTH - 250, WINDOW_HEIGHT - 80))

    title = font_small.render("CATHEDRAL SHOWDOWN", True, (180, 100, 100))
    screen.blit(title, (20, 20))

    hint = font_small.render(
        "WASD: Move | Mouse: Aim | SPACE: Fire | R: Reload | SHIFT: Sprint", True, (150, 150, 150))
    screen.blit(hint, (WINDOW_WIDTH // 2 - 280, WINDOW_HEIGHT - 25))


def draw_game_over():
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    glOrtho(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()
    glDisable(GL_LIGHTING)
    glDisable(GL_DEPTH_TEST)
    glDisable(GL_FOG)

    glColor4f(0.0, 0.0, 0.0, 0.85)
    glBegin(GL_QUADS)
    glVertex2f(0, 0)
    glVertex2f(WINDOW_WIDTH, 0)
    glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT)
    glVertex2f(0, WINDOW_HEIGHT)
    glEnd()

    glColor4f(0.8, 0.1, 0.1, 0.6)
    glLineWidth(8)
    glBegin(GL_LINE_LOOP)
    glVertex2f(50, 50)
    glVertex2f(WINDOW_WIDTH - 50, 50)
    glVertex2f(WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50)
    glVertex2f(50, WINDOW_HEIGHT - 50)
    glEnd()

    glEnable(GL_FOG)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_LIGHTING)
    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)

    game_over_text = font_giant.render("YOU DIED", True, (220, 30, 30))
    screen.blit(game_over_text, (WINDOW_WIDTH // 2 -
                game_over_text.get_width() // 2, WINDOW_HEIGHT // 2 - 120))

    souls_text = font_big.render(
        f"SOULS COLLECTED: {state.score}", True, (255, 220, 100))
    screen.blit(souls_text, (WINDOW_WIDTH // 2 -
                souls_text.get_width() // 2, WINDOW_HEIGHT // 2 + 10))

    restart_text = font_med.render(
        "PRESS [ENTER] TO RETURN TO CATHEDRAL", True, (200, 200, 200))
    screen.blit(restart_text, (WINDOW_WIDTH // 2 -
                restart_text.get_width() // 2, WINDOW_HEIGHT // 2 + 100))

    subtitle = font_small.render(
        "bootleg ultrakill · no gods, only blood", True, (120, 60, 60))
    screen.blit(subtitle, (WINDOW_WIDTH // 2 -
                subtitle.get_width() // 2, WINDOW_HEIGHT - 80))

# ============ GAME LOGIC ============


def spawn_enemy():
    edge = random.randint(0, 3)
    if edge == 0:
        x = random.uniform(-ARENA_SIZE + 3, ARENA_SIZE - 3)
        z = -ARENA_SIZE + 3
    elif edge == 1:
        x = random.uniform(-ARENA_SIZE + 3, ARENA_SIZE - 3)
        z = ARENA_SIZE - 3
    elif edge == 2:
        x = -ARENA_SIZE + 3
        z = random.uniform(-ARENA_SIZE + 3, ARENA_SIZE - 3)
    else:
        x = ARENA_SIZE - 3
        z = random.uniform(-ARENA_SIZE + 3, ARENA_SIZE - 3)

    state.enemies.append({
        'pos': [x, 0.7, z],
        'radius': 0.7,
        'speed': ENEMY_SPEED * random.uniform(0.85, 1.15),
        'phase': random.uniform(0, math.pi * 2),
        'health': 1,
    })


def shoot():
    if not state.game_active or state.reloading or state.ammo <= 0:
        return

    state.ammo -= 1
    state.recoil = 1.0
    state.muzzle_flash = 1.0
    state.shake = 0.08

    yaw_rad = math.radians(state.player_yaw)
    pitch_rad = math.radians(state.player_pitch)

    dx = -math.sin(yaw_rad) * math.cos(pitch_rad)
    dy = math.sin(pitch_rad)
    dz = -math.cos(yaw_rad) * math.cos(pitch_rad)

    length = math.sqrt(dx*dx + dy*dy + dz*dz)
    dx /= length
    dy /= length
    dz /= length

    state.bullets.append({
        'pos': [state.player_pos[0], state.player_pos[1], state.player_pos[2]],
        'vel': [dx * BULLET_SPEED, dy * BULLET_SPEED, dz * BULLET_SPEED],
        'life': BULLET_LIFETIME,
    })


def start_reload():
    if state.reloading or state.ammo == MAX_AMMO:
        return
    state.reloading = True
    state.reload_timer = RELOAD_TIME


def damage_player(amount):
    if not state.game_active:
        return
    state.health -= amount
    state.hit_flash = 1.0
    state.shake = 0.15

    if state.health <= 0:
        state.health = 0
        state.game_active = False
        pygame.mouse.set_visible(True)
        pygame.event.set_grab(False)


def check_arena_collision(pos, radius):
    pos[0] = max(-ARENA_SIZE + radius + 1,
                 min(ARENA_SIZE - radius - 1, pos[0]))
    pos[2] = max(-ARENA_SIZE + radius + 1,
                 min(ARENA_SIZE - radius - 1, pos[2]))


def update():
    if not state.game_active:
        return

    keys = pygame.key.get_pressed()
    sprinting = keys[K_LSHIFT]

    yaw_rad = math.radians(state.player_yaw)
    forward_x = -math.sin(yaw_rad)
    forward_z = -math.cos(yaw_rad)
    right_x = math.cos(yaw_rad)
    right_z = -math.sin(yaw_rad)

    input_x = 0.0
    input_z = 0.0
    if keys[K_w]:
        input_x += forward_x
        input_z += forward_z
    if keys[K_s]:
        input_x -= forward_x
        input_z -= forward_z
    if keys[K_a]:
        input_x -= right_x
        input_z -= right_z
    if keys[K_d]:
        input_x += right_x
        input_z += right_z

    input_len = math.hypot(input_x, input_z)
    if input_len > 0:
        input_x /= input_len
        input_z /= input_len

    strafe_input = 0.0
    if keys[K_a]:
        strafe_input -= 1.0
    if keys[K_d]:
        strafe_input += 1.0
    state.target_roll = -strafe_input * 3.5

    if sprinting and input_len > 0:
        target_fov = SPRINT_FOV
    else:
        target_fov = BASE_FOV
    state.fov_current += (target_fov - state.fov_current) * 0.12

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(state.fov_current, WINDOW_WIDTH /
                   WINDOW_HEIGHT, NEAR_PLANE, FAR_PLANE)
    glMatrixMode(GL_MODELVIEW)

    speed = PLAYER_SPRINT if sprinting else PLAYER_SPEED
    target_vx = input_x * speed
    target_vz = input_z * speed

    if input_len > 0:
        state.velocity[0] += (target_vx - state.velocity[0]) * 0.20
        state.velocity[1] += (target_vz - state.velocity[1]) * 0.20
    else:
        state.velocity[0] *= PLAYER_FRICTION
        state.velocity[1] *= PLAYER_FRICTION
        if abs(state.velocity[0]) < 0.001:
            state.velocity[0] = 0.0
        if abs(state.velocity[1]) < 0.001:
            state.velocity[1] = 0.0

    prev_speed = math.hypot(state.velocity[0], state.velocity[1])

    new_x = state.player_pos[0] + state.velocity[0]
    new_z = state.player_pos[2] + state.velocity[1]

    for px in [-12, 12]:
        for pz in [-12, -4, 4, 12]:
            if math.hypot(new_x - px, new_z - pz) < 1.5:
                dx = new_x - px
                dz = new_z - pz
                d = math.hypot(dx, dz)
                if d > 0:
                    new_x = px + (dx / d) * 1.5
                    new_z = pz + (dz / d) * 1.5

    state.player_pos[0] = new_x
    state.player_pos[2] = new_z
    check_arena_collision(state.player_pos, 0.8)

    state.player_yaw += (state.target_yaw - state.player_yaw) * MOUSE_SMOOTH
    state.player_pitch += (state.target_pitch -
                           state.player_pitch) * MOUSE_SMOOTH

    state.weapon_sway_x += (-state.mouse_vel_x * 0.5 -
                            state.weapon_sway_x) * 0.12
    state.weapon_sway_y += (-state.mouse_vel_y * 0.5 -
                            state.weapon_sway_y) * 0.12
    state.mouse_vel_x *= 0.75
    state.mouse_vel_y *= 0.75

    current_speed = math.hypot(state.velocity[0], state.velocity[1])
    target_bob_amount = min(1.0, current_speed /
                            PLAYER_SPEED) if current_speed > 0.01 else 0.0
    state.bob_amount += (target_bob_amount - state.bob_amount) * 0.15
    state.bob_phase += 0.15 * (0.5 + target_bob_amount)

    state.roll += (state.target_roll - state.roll) * 0.12

    if input_len == 0 and prev_speed > 0.02:
        state.land_dip = min(0.08, prev_speed * 0.4)
    state.land_dip *= 0.85
    if state.land_dip < 0.001:
        state.land_dip = 0.0

    if state.recoil > 0:
        state.recoil -= 0.08
        if state.recoil < 0:
            state.recoil = 0
    if state.muzzle_flash > 0:
        state.muzzle_flash -= 0.15
        if state.muzzle_flash < 0:
            state.muzzle_flash = 0
    if state.hit_flash > 0:
        state.hit_flash -= 0.08
        if state.hit_flash < 0:
            state.hit_flash = 0
    if state.shake > 0:
        state.shake *= 0.88
        if state.shake < 0.001:
            state.shake = 0

    if state.reloading:
        state.reload_timer -= 1
        if state.reload_timer <= 0:
            state.reloading = False
            state.ammo = MAX_AMMO

    state.spawn_timer -= 1
    if state.spawn_timer <= 0:
        spawn_enemy()
        base_interval = max(40, ENEMY_SPAWN_INTERVAL - state.score * 4)
        state.spawn_timer = base_interval

    for b in state.bullets[:]:
        b['pos'][0] += b['vel'][0]
        b['pos'][1] += b['vel'][1]
        b['pos'][2] += b['vel'][2]
        b['life'] -= 1

        if (b['life'] <= 0 or
            abs(b['pos'][0]) > ARENA_SIZE or
            b['pos'][1] < 0 or b['pos'][1] > 12 or
                abs(b['pos'][2]) > ARENA_SIZE):
            state.bullets.remove(b)
            continue

        hit = False
        for e in state.enemies[:]:
            dx = b['pos'][0] - e['pos'][0]
            dy = b['pos'][1] - e['pos'][1]
            dz = b['pos'][2] - e['pos'][2]
            if dx*dx + dy*dy + dz*dz < (e['radius'] + 0.1) ** 2:
                state.enemies.remove(e)
                state.score += 1
                state.hit_flash = 1.0
                state.kill_effects.append({
                    'pos': e['pos'][:],
                    'life': 20,
                })
                hit = True
                break
        if hit and b in state.bullets:
            state.bullets.remove(b)

    for e in state.enemies[:]:
        dx = state.player_pos[0] - e['pos'][0]
        dz = state.player_pos[2] - e['pos'][2]
        dist = math.hypot(dx, dz)

        if dist > 0:
            e['pos'][0] += (dx / dist) * e['speed']
            e['pos'][2] += (dz / dist) * e['speed']

        e['phase'] += 0.08

        if dist < 1.3:
            damage_player(15)
            if e in state.enemies:
                state.enemies.remove(e)
            state.kill_effects.append({
                'pos': e['pos'][:],
                'life': 20,
            })

    for k in state.kill_effects[:]:
        k['life'] -= 1
        if k['life'] <= 0:
            state.kill_effects.remove(k)


def draw_kill_effects():
    glDisable(GL_LIGHTING)
    for k in state.kill_effects:
        alpha = k['life'] / 20.0
        glColor4f(1.0, 0.3, 0.1, alpha)
        glPushMatrix()
        glTranslatef(k['pos'][0], k['pos'][1] + (1 - alpha) * 2, k['pos'][2])
        quad = gluNewQuadric()
        gluSphere(quad, 0.5 * alpha + 0.2, 8, 8)
        gluDeleteQuadric(quad)
        glPopMatrix()
    glEnable(GL_LIGHTING)

# ============ RENDER ============


def render():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    shake_x = random.uniform(-state.shake, state.shake) * 10
    shake_y = random.uniform(-state.shake, state.shake) * 10

    # Correct FPS camera order: roll -> yaw -> pitch
    glRotatef(state.roll + shake_x * 0.5, 0, 0, 1)
    glRotatef(state.player_yaw, 0, 1, 0)
    glRotatef(state.player_pitch + shake_y, 1, 0, 0)

    bob_y = abs(math.sin(state.bob_phase)) * 0.05 * state.bob_amount
    bob_x = math.sin(state.bob_phase * 0.5) * 0.03 * state.bob_amount
    cam_y = state.player_pos[1] - bob_y - state.land_dip

    glTranslatef(-state.player_pos[0] - bob_x * 0.3,
                 -cam_y,
                 -state.player_pos[2])

    glLightfv(GL_LIGHT0, GL_POSITION, [
              state.player_pos[0] + 5, 15, state.player_pos[2] + 5, 1.0])

    draw_cathedral()
    for b in state.bullets:
        draw_bullet(b)
    for e in state.enemies:
        draw_enemy(e)
    draw_kill_effects()

    draw_weapon()
    draw_crosshair()
    draw_hud()

    if not state.game_active:
        draw_game_over()


# ============ MAIN LOOP ============
screen = pygame.display.get_surface()
clock = pygame.time.Clock()

pygame.mouse.set_visible(False)
pygame.event.set_grab(True)
pygame.mouse.get_rel()

running = True
while running:
    dt = clock.tick(60)

    for event in pygame.event.get():
        if event.type == QUIT:
            running = False
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                running = False
            elif event.key == K_SPACE:
                if state.game_active:
                    shoot()
            elif event.key == K_r:
                if state.game_active:
                    start_reload()
            elif event.key == K_RETURN:
                if not state.game_active:
                    state.reset()
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()

        elif event.type == MOUSEBUTTONDOWN:
            if event.button == 1 and state.game_active:
                shoot()

        elif event.type == MOUSEMOTION:
            if state.game_active:
                dx, dy = event.rel
                state.target_yaw -= dx * MOUSE_SENSITIVITY
                if INVERT_Y:
                    state.target_pitch -= dy * MOUSE_SENSITIVITY
                else:
                    state.target_pitch += dy * MOUSE_SENSITIVITY
                state.target_pitch = max(-89, min(89, state.target_pitch))
                state.mouse_vel_x += dx
                state.mouse_vel_y += dy

    update()
    render()
    draw_hud_text()

    pygame.display.flip()

pygame.quit()
sys.exit()
